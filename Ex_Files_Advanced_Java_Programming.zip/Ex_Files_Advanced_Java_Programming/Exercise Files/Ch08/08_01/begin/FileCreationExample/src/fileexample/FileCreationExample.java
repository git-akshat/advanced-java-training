
package fileexample;



public class FileCreationExample {

    public static void main(String[] args) {
        

    }
    
}