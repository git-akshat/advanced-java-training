
package scannerexample;

import java.util.Scanner;

/**
 *
 * @author bethan
 */
public class PersonCreator {
    
    public static void main(String[] args) {
        


        
    }
    
}
