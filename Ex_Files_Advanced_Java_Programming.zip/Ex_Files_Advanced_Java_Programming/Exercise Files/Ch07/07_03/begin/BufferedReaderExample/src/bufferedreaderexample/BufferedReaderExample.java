package bufferedreaderexample;


/**
 *
 * @author bethan
 */
public class BufferedReaderExample {

    public static void main(String[] args) {


    }

}
