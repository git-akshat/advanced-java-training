
package helloworld;

import java.awt.image.BufferedImage;


/**
 *
 * @author bethan
 */

public class Greeting {
    
    BufferedImage image;

    public static void main(String[] args) {
        System.out.println("Hello world");                
    }
    
}
