
package helloworld;


/**
 *
 * @author bethan
 */

public class Greeting {

    public static void main(String[] args) {
        System.out.println("Hello world");                
    }
    
}
