
package customers;


/**
 *
 * @author Bethan
 */
public class Customer {
    
    public static void main(String[] args) {
        
    }
    
}
