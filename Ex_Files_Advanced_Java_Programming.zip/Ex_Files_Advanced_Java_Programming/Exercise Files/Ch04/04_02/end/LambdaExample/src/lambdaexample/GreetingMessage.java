
package lambdaexample;

/**
 *
 * @author bethan
 */
@FunctionalInterface
public interface GreetingMessage {
    
    public abstract void greet(String name);    
    
    
}
