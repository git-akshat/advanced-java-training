
package lambdaexample;

/**
 *
 * @author bethan
 */
@FunctionalInterface
public interface MessagePrinter {
    
    public abstract void printMessage();
    
}
