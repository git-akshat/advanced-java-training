
package substitution_principle;

/**
 *
 * @author bethan
 */
class Office extends Building {        
    
    @Override
    public String toString() {
        return ("office");
    }
    
    
}
