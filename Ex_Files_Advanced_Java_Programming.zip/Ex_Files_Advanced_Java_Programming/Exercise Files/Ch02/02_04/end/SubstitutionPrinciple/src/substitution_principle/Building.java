
package substitution_principle;

/**
 *
 * @author bethan
 */
class Building {
    
    @Override
    public String toString() {
        return("building");
    }
    
}



