
package wildcards;


/**
 *
 * @author bethan
 */
class Office extends Building {        
    
    @Override
    public String toString() {
        return ("office");
    }
    
    
}
