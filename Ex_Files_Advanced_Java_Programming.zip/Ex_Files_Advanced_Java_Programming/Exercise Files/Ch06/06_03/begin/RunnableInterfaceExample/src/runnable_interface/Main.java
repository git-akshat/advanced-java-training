
package runnable_interface;

/**
 *
 * @author bethan
 */
public class Main {

    public static void main(String[] args) {

    }

}
